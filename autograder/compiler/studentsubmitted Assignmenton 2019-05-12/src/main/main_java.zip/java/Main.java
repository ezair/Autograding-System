/**
 * The main class demonstrating the Card class. Pretty much "Hello,
 * World!" at the moment.
 */
public class Main {
  /**
   * Create a Main object to run and then run it.
   *
   * @param args
   */
  public static void main(String[] args) {
    Main main = new Main();
    main.run();
  }

  /**
   * Do the real work of the class.
   */
  public void run() {
    System.out.println(String.format("Cards"));
  }
}

/**
 * What happens when we deal past the bottom of the deck.
 * Created by blad on 1/15/15.
 */
public class DeckUnderflowException extends RuntimeException {
}
